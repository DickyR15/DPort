from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any

LOGGER = logging.getLogger("DPort.updater")
REPO = os.environ.get("DPORT_UPDATE_REPO", "DickyR15/DPort")
RELEASE_API = f"https://api.github.com/repos/{REPO}/releases/latest"
CHECK_INTERVAL = 6 * 60 * 60
CACHE_MAX_AGE = 24 * 60 * 60
_VERSION_RE = re.compile(r"^v?(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:\.([0-9A-Za-z.-]+))?$")

_BOOTSTRAP_DONE = False
_LOCK = threading.Lock()
_STATE: dict[str, Any] = {
    "current_version": None,
    "latest_version": None,
    "latest_url": "",
    "state": "idle",
    "message": "",
    "checked_at": 0,
    "updated_at": 0,
    "restart_required": False,
}


def _version_key(value: str) -> tuple[int, int, int, str]:
    m = _VERSION_RE.match(str(value).strip())
    if not m:
        return (0, 0, 0, str(value))
    return (int(m.group(1) or 0), int(m.group(2) or 0), int(m.group(3) or 0), m.group(4) or "")


def _state_dir() -> Path:
    root = os.environ.get("LOCALAPPDATA")
    if root:
        return Path(root) / "DPort"
    return Path.home() / ".dport"


def _state_file() -> Path:
    return _state_dir() / "update_state.json"


def _load_state() -> None:
    try:
        data = json.loads(_state_file().read_text(encoding="utf-8"))
        if isinstance(data, dict):
            _STATE.update(data)
    except Exception:
        pass


def _save_state() -> None:
    try:
        p = _state_file()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(_STATE, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        LOGGER.debug("Unable to save DPort updater state: %s", exc)


def _bundled_version() -> str:
    try:
        from dport_version import DPORT_VERSION
        return str(DPORT_VERSION)
    except Exception:
        return "6.9.0"


def _github_json(url: str) -> dict[str, Any]:
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "DPort-Updater",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        value = json.loads(resp.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("GitHub API 回傳格式無效")
    return value


def _find_release_assets(release: dict[str, Any]) -> tuple[str, str, str] | None:
    tag = str(release.get("tag_name") or "").strip()
    if not _VERSION_RE.match(tag):
        return None
    version = tag.lstrip("v")
    exe_name = f"DPort-{version}.exe"
    sha_name = f"DPort-{version}.exe.sha256"
    exe_url = ""
    sha_url = ""
    for asset in release.get("assets") or []:
        if not isinstance(asset, dict):
            continue
        name = asset.get("name")
        url = asset.get("browser_download_url")
        if name == exe_name and url:
            exe_url = str(url)
        elif name == sha_name and url:
            sha_url = str(url)
    if not exe_url or not sha_url:
        return None
    return tag, exe_url, sha_url


def _get_update_candidate(current: str) -> tuple[str, str, str, str] | None:
    data = _github_json(RELEASE_API + f"?dport_cache_bust={time.time_ns()}")
    if data.get("draft") or data.get("prerelease"):
        return None
    release = _find_release_assets(data)
    if release is None:
        raise RuntimeError("最新正式 Release 沒有可用的 DPort EXE")
    tag, exe_url, sha_url = release
    if _version_key(tag) <= _version_key(current):
        return None
    return tag.lstrip("v"), exe_url, sha_url, str(data.get("html_url") or "")


def _embedded_helper() -> Path | None:
    meipass = getattr(sys, "_MEIPASS", None)
    candidates = []
    if meipass:
        candidates.append(Path(meipass) / "dport_updater" / "DPortUpdater.exe")
    exe_dir = Path(sys.executable).resolve().parent
    candidates.extend([
        exe_dir / "dport_updater" / "DPortUpdater.exe",
        exe_dir / "DPortUpdater.exe",
    ])
    for p in candidates:
        if p.exists():
            return p
    return None


def _materialize_helper() -> Path | None:
    src = _embedded_helper()
    if src is None:
        return None
    out_dir = Path(tempfile.gettempdir()) / "DPort" / "updater"
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"DPortUpdater-{os.getpid()}-{time.time_ns()}.exe"
    try:
        target.write_bytes(src.read_bytes())
        return target
    except Exception as exc:
        LOGGER.warning("Cannot materialize updater helper: %s", exc)
        return None


def _launch_update(version: str, exe_url: str, sha_url: str, release_url: str) -> None:
    helper = _materialize_helper()
    if helper is None:
        with _LOCK:
            _STATE["state"] = "update_unavailable"
            _STATE["message"] = "無法啟動內建更新元件，已保留目前版本。"
        _save_state()
        return

    current_exe = Path(sys.executable).resolve()
    args = list(sys.argv[1:]) if getattr(sys, "frozen", False) else []
    with _LOCK:
        _STATE["state"] = "updating"
        _STATE["latest_version"] = version
        _STATE["latest_url"] = release_url
        _STATE["message"] = f"正在下載並安裝 DPort v{version}…"
    _save_state()

    cmd = [
        str(helper),
        "--pid", str(os.getpid()),
        "--target", str(current_exe),
        "--version", version,
        "--exe-url", exe_url,
    ]
    if sha_url:
        cmd.extend(["--sha256-url", sha_url])
    if args:
        cmd.extend(["--args-json", json.dumps(args, ensure_ascii=False)])
    try:
        subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            close_fds=True,
        )
    except Exception as exc:
        LOGGER.warning("Unable to launch update helper: %s", exc)
        with _LOCK:
            _STATE["state"] = "update_failed"
            _STATE["message"] = f"更新程式啟動失敗：{exc}"
        _save_state()
        return

    # Allow the UI to render the restart state before this process exits.
    time.sleep(0.5)
    with _LOCK:
        _STATE["state"] = "restarting"
        _STATE["message"] = f"DPort v{version} 更新完成，正在重新啟動…"
        _STATE["updated_at"] = time.time()
        _STATE["restart_required"] = False
    _save_state()
    os._exit(0)


def check_now(force: bool = False) -> dict[str, Any]:
    with _LOCK:
        now = time.time()
        if not force and now - float(_STATE.get("checked_at") or 0) < CACHE_MAX_AGE:
            return dict(_STATE)
        _STATE["state"] = "checking"
        _STATE["latest_version"] = None
        _STATE["latest_url"] = ""
        _STATE["message"] = "正在檢查 GitHub 最新正式版…"
    current = _bundled_version()
    try:
        candidate = _get_update_candidate(current)
        with _LOCK:
            _STATE["current_version"] = current
            _STATE["checked_at"] = time.time()
        if candidate is None:
            with _LOCK:
                _STATE["state"] = "latest"
                _STATE["latest_version"] = current
                _STATE["message"] = f"DPort v{current} 已是最新正式版"
                _STATE["restart_required"] = False
        else:
            version, exe_url, sha_url, release_url = candidate
            with _LOCK:
                _STATE["state"] = "update_available"
                _STATE["latest_version"] = version
                _STATE["latest_url"] = release_url
                _STATE["message"] = f"發現 DPort 新版 v{version}，準備自動更新…"
            _save_state()
            _launch_update(version, exe_url, sha_url, release_url)
    except Exception as exc:
        LOGGER.info("DPort update check skipped: %s", exc)
        with _LOCK:
            _STATE["state"] = "offline"
            _STATE["message"] = str(exc)
            _STATE["checked_at"] = time.time()
            _STATE["current_version"] = current
    _save_state()
    return get_status()


def get_status() -> dict[str, Any]:
    with _LOCK:
        return dict(_STATE)


def bootstrap() -> None:
    global _BOOTSTRAP_DONE
    if _BOOTSTRAP_DONE:
        return
    _BOOTSTRAP_DONE = True
    _load_state()
    current = _bundled_version()
    with _LOCK:
        _STATE["current_version"] = current
        if os.environ.pop("DPORT_RESTARTED", None) == "1":
            _STATE["state"] = "latest"
            _STATE["latest_version"] = current
            _STATE["message"] = "DPort 已重新啟動，新版本已套用。"
            _STATE["restart_required"] = False
            _save_state()


def start_background_update_check() -> None:
    def runner() -> None:
        try:
            _load_state()
            if os.environ.get("DPORT_RESTARTED") == "1":
                return
            check_now(force=True)
        except Exception as exc:
            LOGGER.debug("DPort updater worker failed: %s", exc)
    threading.Thread(target=runner, name="DPort-release-updater", daemon=True).start()
